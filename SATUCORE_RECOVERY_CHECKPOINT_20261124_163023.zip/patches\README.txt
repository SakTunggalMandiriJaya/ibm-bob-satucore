SATUCORE Patient Mapping Fix

Patch target based on the uploaded source snapshots:
- src/App.tsx (uploaded App(20261122-090954).tsx)
- src/lib/workflow.ts (uploaded workflow(20261122-092937).ts)

What this changes:
1. Improves deterministic header recommendations for common Indonesian and English Patient fields (e.g. no_rekam_medis, tgl_lahir, nama_pasien).
2. Uses sample values only to increase confidence for an already-recognised DOB/NIK header. It does NOT infer DOB or MRN from arbitrary date/number values.
3. Blocks semantically contradictory mappings (e.g. dob -> identifier; patient_no -> birthDate).
4. Blocks multiple approved sources for single-valued identity targets (identifier, national_identifier, name, birthDate, gender).
5. Enforces those checks in mapping persistence, Patient Draft save, validation, canonical Patient persistence, and browser validation/save gates.
6. Does not auto-correct a user's mapping. It reports the conflict and requires a human correction.

Apply safely from the repository root in PowerShell:

  git status --short
  git apply --check .\path\to\App-mapping-fix.patch
  git apply --check .\path\to\workflow-mapping-fix.patch

Only if BOTH checks pass:

  git apply .\path\to\App-mapping-fix.patch
  git apply .\path\to\workflow-mapping-fix.patch

If either check fails, DO NOT force the patch and DO NOT replace the whole App.tsx. Upload the current src/App.tsx and src/lib/workflow.ts so the patch can be rebased against the latest local files.

Then run:
  npm run build
  npm test

Test cases included in test-mapping-logic.cjs:
  node .\path\to\test-mapping-logic.cjs

Important verification limitation:
- The mapping logic test passed in this environment.
- TypeScript parsing produced no syntax diagnostics.
- A full build was not possible here because the uploaded source snapshot does not include the project package.json, node_modules, or companion source files. The remaining tsc messages are unresolved dependency/type-context diagnostics, not verified build success.
