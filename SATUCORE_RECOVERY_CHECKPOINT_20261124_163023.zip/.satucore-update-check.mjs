﻿import { createClient } from "@supabase/supabase-js";
import { readFileSync } from "node:fs";

const env = Object.fromEntries(
  readFileSync(".env", "utf8")
    .split(/\r?\n/)
    .filter(line => /^\s*VITE_SUPABASE_(URL|PUBLISHABLE_KEY)=/.test(line))
    .map(line => {
      const i = line.indexOf("=");
      return [line.slice(0, i).trim(), line.slice(i + 1).trim().replace(/^["']|["']$/g, "")];
    })
);

const db = createClient(
  env.VITE_SUPABASE_URL,
  env.VITE_SUPABASE_PUBLISHABLE_KEY,
  { auth: { persistSession: false, autoRefreshToken: false } }
);

try {
  const { data: auth, error: loginError } =
    await db.auth.signInWithPassword({
      email: process.env.RLS_TEST_EMAIL,
      password: process.env.RLS_TEST_PASSWORD
    });

  if (loginError) throw loginError;
  if (auth.user.id !== process.env.RLS_EXPECTED_USER) {
    throw new Error("Authenticated user ID mismatch.");
  }

  console.log("Authenticated user verified:", auth.user.id);
  console.log("Foreign import target:", process.env.RLS_FOREIGN_IMPORT);

  const { data, error } = await db
    .from("data_imports")
    .update({ status: "review" })
    .eq("id", process.env.RLS_FOREIGN_IMPORT)
    .select("id");

  if (error) {
    console.log("UPDATE error:", error.code, error.message);
  } else {
    console.log("Rows updated:", data?.length ?? 0);
    console.log(
      (data?.length ?? 0) === 0
        ? "PASS: foreign row was not updateable"
        : "FAIL: foreign row was updated; investigate immediately"
    );
  }
} finally {
  await db.auth.signOut();
}
