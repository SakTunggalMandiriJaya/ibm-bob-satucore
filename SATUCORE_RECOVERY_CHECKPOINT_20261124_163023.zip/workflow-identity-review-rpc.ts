export async function createPatientIdentityReviewRequest(args: {
  workspace: Workspace; importId: string; rowNumber: number; incomingMrn: string; reason: string; candidatePatientId?: string | null
}): Promise<{ requestId: string; existing: boolean }> {
  const { workspace: w, importId, rowNumber, incomingMrn, reason, candidatePatientId = null } = args
  if (!w.organizationId) throw new Error('An active Organization is required for identity review.')
  if (!incomingMrn.trim() || !reason.trim()) throw new Error('MRN and review reason are required.')

  const db = client()
  // Use the database-authorized RPC. Authenticated users intentionally have
  // SELECT-only access to the request table; the RPC performs tenant/role,
  // source-row and candidate checks, idempotency, and audit logging atomically.
  const { data, error } = await db.rpc('create_patient_identity_review_request', {
    p_tenant_id: w.tenantId,
    p_organization_id: w.organizationId,
    p_import_id: importId,
    p_row_number: rowNumber,
    p_incoming_mrn: incomingMrn.trim(),
    p_reason: reason.trim(),
    p_candidate_patient_id: candidatePatientId
  })

  if (error) throw error
  const result = Array.isArray(data) ? data[0] : data
  if (!result?.request_id) {
    throw new Error('Identity-review RPC returned no request ID. The request was not confirmed.')
  }

  return {
    requestId: result.request_id,
    existing: Boolean(result.existing)
  }
}
