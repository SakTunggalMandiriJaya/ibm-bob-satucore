const assert = require('node:assert/strict');
const normalize = value => value.toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
const roleForSource = source => {
  const key = normalize(source);
  if (/^(dob|patientdob|birthdate|birthdt|dateofbirth|tanggallahir|tgllahir|tglahir)$/.test(key)) return 'birthDate';
  if (/^(mrn|mrnno|medicalrecord|medicalrecordno|medicalrecordnumber|patientno|patientnumber|patientid|patientcode|nomorrm|norm|rekammedis|norekammedis|nomorrekammedis|kodepasien)$/.test(key)) return 'identifier';
  if (/^(nik|nationalid|nationalidentifier|nomorindukkependudukan|niktp|noktp|ktp|nikpasien)$/.test(key)) return 'national_identifier';
  if (/^(name|patientname|fullname|patientfullname|nama|namapasien|namalengkap)$/.test(key)) return 'name';
  if (/^(sex|gender|jeniskelamin)$/.test(key)) return 'gender';
  return null;
};
function patientMappingIssues(fields) {
  const issues=[];
  for (const f of fields.filter(x=>x.approved && x.target !== '—')) {
    const expected=roleForSource(f.source);
    if (expected && expected !== f.target) issues.push(`${f.source} expected ${expected}, got ${f.target}`);
  }
  for (const target of ['identifier','national_identifier','name','birthDate','gender']) {
    const matches=fields.filter(x=>x.approved && x.target===target);
    if(matches.length>1) issues.push(`duplicate ${target}`);
  }
  return issues;
}
const valid=[
 {source:'patient_no',target:'identifier',approved:true},
 {source:'dob',target:'birthDate',approved:true},
 {source:'patient_name',target:'name',approved:true},
 {source:'sex',target:'gender',approved:true},
];
assert.deepEqual(patientMappingIssues(valid), []);
assert(patientMappingIssues([{source:'dob',target:'identifier',approved:true}]).length===1, 'DOB must not map to MRN');
assert(patientMappingIssues([{source:'patient_no',target:'birthDate',approved:true}]).length===1, 'MRN must not map to DOB');
assert(patientMappingIssues([{source:'patient_no',target:'identifier',approved:true},{source:'medical_record_no',target:'identifier',approved:true}]).some(x=>x.includes('duplicate')), 'duplicate identifier mappings must be blocked');
assert.equal(roleForSource('tgl_lahir'),'birthDate');
assert.equal(roleForSource('no_rekam_medis'),'identifier');
assert.equal(roleForSource('nama_pasien'),'name');
console.log('PASS: valid mappings accepted; swapped DOB/MRN, duplicate identity targets, and Indonesian header aliases checked.');
