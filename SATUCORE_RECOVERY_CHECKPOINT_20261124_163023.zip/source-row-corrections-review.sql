﻿-- Persist corrected working values separately; never overwrite import_rows.original_data.
create table if not exists public.source_row_corrections (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete restrict,
  import_id uuid not null references public.data_imports(id) on delete restrict,
  import_row_id uuid not null references public.import_rows(id) on delete restrict,
  row_number integer not null check (row_number > 0),
  source_field text not null check (length(btrim(source_field)) > 0),
  original_value text not null,
  corrected_value text not null,
  reason text not null check (length(btrim(reason)) > 0),
  corrected_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create index if not exists idx_source_row_corrections_tenant_import
  on public.source_row_corrections (tenant_id, import_id, row_number, created_at);
alter table public.source_row_corrections enable row level security;
create policy source_row_corrections_tenant_read
on public.source_row_corrections for select to authenticated
using (exists (
  select 1 from public.tenant_members tm
  where tm.tenant_id = source_row_corrections.tenant_id
    and tm.user_id = (select auth.uid()) and tm.status = 'active'
));
create policy source_row_corrections_authorized_insert
on public.source_row_corrections for insert to authenticated
with check (
  corrected_by = (select auth.uid())
  and exists (
    select 1 from public.tenant_members tm
    where tm.tenant_id = source_row_corrections.tenant_id
      and tm.user_id = (select auth.uid()) and tm.status = 'active'
      and tm.role in ('tenant_admin','clinic_admin','data_manager','clinician','reviewer')
  )
  and exists (
    select 1 from public.import_rows ir
    where ir.id = source_row_corrections.import_row_id
      and ir.import_id = source_row_corrections.import_id
      and ir.tenant_id = source_row_corrections.tenant_id
      and ir.row_number = source_row_corrections.row_number
  )
);
-- No UPDATE or DELETE policy: corrections are append-only evidence.
